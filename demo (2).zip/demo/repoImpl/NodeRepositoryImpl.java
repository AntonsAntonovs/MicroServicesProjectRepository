package com.example.demo.repoImpl;

import com.example.demo.repo.NodeRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository
public class NodeRepositoryImpl {
}
